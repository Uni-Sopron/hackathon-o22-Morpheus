﻿using System;

namespace ConsoleApp3
{
    class Program
    {
        //az algoritmus nézi karakterek helyét, számát, eltéreseket keres és az alapján visszaadja az eltérő karakterek mennyiségét
        public int LevenshteinTavolsag(string megoldas, string tipp)
        {
            //kiskapitálissá átírás
            megoldas = megoldas.ToLower();
            tipp = tipp.ToLower();
            //üresek kezelése
            if (string.IsNullOrEmpty(megoldas)) 
            {
                throw new ArgumentNullException(megoldas, "String Nem Lehet 0 vagy Üres");
            }

            if (string.IsNullOrEmpty(tipp))
            {
                throw new ArgumentNullException(tipp, "String Nem Lehet 0 vagy Üres");
            }

            int mhossz = megoldas.Length; // megoldás hossza = n
            int thossz = tipp.Length; // tipp hossza = m
            
            int[] elozo = new int[mhossz + 1]; //'előző' tömbérték, vízszintes
            int[] d = new int[mhossz + 1]; // tömbérték, vízszintes

            int i; // megoldason átiterál
            int j; // tippen átiterál

            for (i = 0; i <= mhossz; i++)
            {
                elozo[i] = i;
            }
            int[] szamok = elozo; //debugger check
            for (j = 1; j <= thossz; j++)
            {
                char tJ = tipp[j - 1]; // j-edik karaktere tippnek
                d[0] = j;

                for (i = 1; i <= mhossz; i++)
                {
                    int cost = megoldas[i - 1] == tJ ? 0 : 1; // cost -> ha talált, ne növeljen értéket : nem talált, 1-el növeli
                                                       // minimum of cell to the left+1, to the top+1, diagonally left and up +cost                
                    d[i] = Math.Min(Math.Min(d[i - 1] + 1, elozo[i] + 1), elozo[i - 1] + cost);
                }

                // másolja át a jelenlegi különségszámítást az előzőbe
                int[] dPlaceholder = elozo; //csere algoritmushoz ideiglenes tároló
                elozo = d;
                d = dPlaceholder;
            }

            //d és elozo felcserélve, elozo tartalmazza a legutóbbi cost countot (d-ben +1, mert a ciklus szó+1 karakterrel többet fut)
            return elozo[mhossz];
        }
        
        /* első nem működő próbálkozásom
        public int nemHelyes(string megoldas, string tipp)
        {
            int szam1 = megoldas.Length;
            int szam2 = tipp.Length;
            int hossz = 0;
            if ((szam1 - szam2) < 0)
                hossz = (szam2 - szam1);
            else
                hossz = (szam1 - szam2);
            int i = 0;
            int j = 0;
            int korrekt = 0;
            int korrekt2 = 0;
            if (szam1 >= szam2) //5 3
            {
                j = szam1; //5
                while (i != szam1) //0-5
                {
                    while (j != 0) //5-0
                    {
                        if (megoldas[i + hossz] == tipp[i]) //0+2, 0 pl. faalma, alma
                            korrekt++;
                        
                    }
                    i++;
                }      
            }
            else if (szam1 < szam2)
            {
                j = szam1;
                while (i != szam1)
                {
                    while (j != 0)
                    {
                        if (megoldas[i + hossz] == tipp[i])
                            korrekt++;
                        else if (megoldas[j - hossz] == tipp[j])
                            korrekt2++;
                        j--;
                    }
                    i++;
                }
            }
            return (korrekt + korrekt2) / 2;                
        }
        */
        public static void Main(string[] args)
        {
            Program pr = new Program();
            string szo1 = Console.ReadLine();
            string szo2 = Console.ReadLine();
            Console.WriteLine(pr.LevenshteinTavolsag(szo1, szo2));
            if ((pr.LevenshteinTavolsag(szo1, szo2)) == 0 || (pr.LevenshteinTavolsag(szo1, szo2)) == 1) //ha 0 vagy 1 eltérés van, adja meg helyesnek a választ
            {
                Console.WriteLine("Talált!");
            }
            Console.ReadKey();
        }
    }
}
